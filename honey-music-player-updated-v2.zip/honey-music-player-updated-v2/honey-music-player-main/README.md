# ARJ Player - Updated with Modern UI/UX

Optimized with Jetpack Compose and enhanced themes.